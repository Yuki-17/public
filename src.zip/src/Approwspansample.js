import { AgGridReact } from 'ag-grid-react';
import React from 'react';
import './App.css';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';

export default class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      suppressRowTransform:true,
      columnDefs: [
        { headerName: "Make", field: "make",
        rowSpan:function(params){
          var athlete = params.data.make;
          console.log(params)
          console.log(athlete)
      if (athlete === 'Toyota') {
        // have all Russia age columns width 2
        console.log(111111111111)
        return 2; 
      } else {
        // all other rows should be just normal
        return 1;
      }
        },       
        cellClassRules: {
          'background-color': 'blue'
        }, 
        cellStyle:{color:'red',border: '1px solid black','background-color': 'white'},
         },
        { headerName: "Model", field: "model" },
        { headerName: "Price", field: "price" }],
      rowData: [
        { make: "Toyota", model: "Celica", price: 35000},
        { make: "Ford", model: "Mondeo", price: 32000 },
        { make: "Porsche", model: "Boxter", price: 72000 }]
    }
  }

  render() {
    console.log(this.state.columnDefs)
    return (
      <div className="ag-theme-alpine" style={ {height: '200px', width: '600px'} }>
        <AgGridReact
            columnDefs={this.state.columnDefs}
            rowData={this.state.rowData}
            suppressRowTransform={this.state.suppressRowTransform}
            >
            
        </AgGridReact>
      </div>
    );
  }
}
