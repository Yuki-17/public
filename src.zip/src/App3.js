import React ,{useEffect} from 'react';
import {testdata1} from './Data.js';
import "leaflet/dist/leaflet.css";
import "leaflet-legend/leaflet-legend.css";
import L from "leaflet";
import HeatmapOverlay from 'leaflet-heatmap';
import 'leaflet-timedimension';
import "leaflet-timedimension/dist/leaflet.timedimension.control.min.css";
//import "leaflet-legend";
import "leaflet-html-legend";
import "leaflet-html-legend/dist/L.Control.HtmlLegend.css"
//import $ from 'jquery';
//import dateFormat from 'dateformat';
//import blueIcon from './marker-icon.png';
//import greenIcon from './marker-icon-green.png';
//import redIcon from  './marker-icon-red.png';

const position = [32.560991, 131.677264]
var startDate = new Date();
startDate.setUTCHours(0, 0, 0, 0);
var endDate = new Date(startDate.getTime());
L.TimeDimension.Util.addTimeDuration(endDate, 'P1M', false);
const testdata = testdata1;
console.log(startDate)
console.log(endDate)

var float1 = '0.4';

// データ取得
var len = Object.keys(testdata).length;
var times = []
for (let i = 0; i < len; i++){
  times[i] = i + 1;
}

export default function WindMap() {
  useEffect(() => {
    console.log("useEffect");
//ココカラ################################################################################### 
var TDHeatmap = L.TimeDimension.Layer.extend({
    initialize: function(data, options) {
      var layer = new HeatmapOverlay(options.heatmapOptions);
　　　//初期化
      L.TimeDimension.Layer.prototype.initialize.call(this, layer, options);
      this._currentLoadedTime = 0;
      this._currentTimeData = {
        data: []
       };
      this.data= data;
    },

　　onAdd: function(map) {
      console.log("onadd");
      L.TimeDimension.Layer.prototype.onAdd.call(this, map);
      map.addLayer(this._baseLayer);
      if (this._timeDimension) {
          this._getDataForTime(this._timeDimension.getCurrentTime());
      }
　　},
    // 時間を変更したときに実行される処理の設定
    _onNewTimeLoading: function(ev) {
      console.log("onNewTimeLoading");
      this._getDataForTime(ev.time);
      return;
　　},
    // 手動で時間を変更したときに必要になる。時間が変更されるとfalseになりデータを変更できる？
　　isReady: function(time) {
      console.log("isReady");
      return (this._currentLoadedTime == time);
　　},
    // 初回読み込み時と時間を変更したときに実行される
　　_update: function() {
      console.log("_update")
      this._baseLayer.setData(this._currentTimeData);
      return true;
　　}, 
    // 自前の関数　引数に与えられた時間のデータをセットする
　　_getDataForTime: function(time) {
      console.log(time)  
      console.log("_getDataForTime")
      // 現在のデータを削除する。
      delete this._currentTimeData.data;
      // データ初期化
      this._currentTimeData.data = [];
      // データセット(配列のため-1)
      var tmp = times.indexOf([time])
      var data = this.data[time-1];
      console.log(tmp)
      console.log(data)
      // データの個数だけループ
      for (var i = 0; i < data.length; i++) {
        this._currentTimeData.data.push({
          lat: data[i][0],
          lng: data[i][1],
          count1: data[i].length>2 ? data[i][2] : this.defaultWeight
        });
      }
      console.log(this._currentTimeData.data)
      this._currentLoadedTime = time;
      // 初回読み込み用
      if (this._timeDimension && time == this._timeDimension.getCurrentTime() && !this._timeDimension.isLoading()) {
        this._update();
      }
      this.fire('timeload', {
        time: time
      });
    }
});

// 時系列変化の設定
// ここを設定しないとmap連動しないよ
L.Control.TimeDimensionCustom = L.Control.TimeDimension.extend({
  initialize: function(index, options) {
    console.log("L.control initialize")
    console.log(index)
    console.log(options)
    var playerOptions = {
        buffer: 1,
        minBufferReady: -1,
        };
    options.playerOptions = Object.assign({}, playerOptions, options.playerOptions || {});
    console.log(options.playerOptions)
    L.Control.TimeDimension.prototype.initialize.call(this, options);
    // 時間軸を設定する
    this.index = index;

  },
  _getDisplayDateFormat: function(date){
    console.log("L.control _getDisplayDateFormat")
    console.log(date)
    console.log(date.getTime()-1)
    console.log(this.index[date.getTime()-1])

    var d = new Date(1)
console.log(d)
console.log(d.getTime())
    return this.index[date.getTime()-1];
  },
});

var map = L.map(
    "map",{
      center: position,
      crs: L.CRS.EPSG3857,
      zoom: 16,
      zoomControl: true,
      preferCanvas: false,
      minZoom: 0,
      maxZoom: 18,
    }
);

var tilelayer = L.tileLayer(
    "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
    {"attribution": "Data by \u0026copy; \u003ca href=\"http://openstreetmap.org\"\u003eOpenStreetMap\u003c/a\u003e, under \u003ca href=\"http://www.openstreetmap.org/copyright\"\u003eODbL\u003c/a\u003e.", "noWrap": false, "subdomains": "abc"}
).addTo(map);

map.timeDimension = L.timeDimension(
    {times : times, currentTime: 1},
);

var timedimensioncustom = new L.Control.TimeDimensionCustom(['9時', '10時', '11時', '12時', '13時'], { 
  // 開いた瞬間に時系列変化の流すかどうか
  autoPlay:false,
  // 再生、巻き戻しボタン
  playButton: true,
  playReverseButton: true,
  // 1つ進む、1つ戻るボタン
  backwardButton: true,
  forwardButton: true,
  // 日付表示有無
  displayDate: true,
  // 
  limitMinimumRange: 1,
  limitSliders:false,
  // 繰り返し機能
  loopButton: false,
  // fps設定有無、fpsの最大値、最小値(default)、fpsメッシュ
  speedSlider: true,
  maxSpeed: 20,
  minSpeed: 1,
  speedStep: 0.1,
　// 時系列窓の表示位置
  position: "bottomleft",
  // 時系列窓のスタイル
  styleNS: "leaflet-control-timecontrol",
  // スライダー有無
  timeSlider: true,
  // ドラッグ時に地図を更新する
  timeSliderDrapUpdate: false,
  // 時間のメッシュ
  timeSteps: 1,
  
//})
}).addTo(map);
var m = L.circle([32.570991, 131.677264]).addTo(map);


// legend##############################################
var gsi = L.tileLayer('https://cyberjapandata.gsi.go.jp/xyz/std/{z}/{x}/{y}.png', { attribution: gsiattr });
var gsipale = L.tileLayer('http://cyberjapandata.gsi.go.jp/xyz/pale/{z}/{x}/{y}.png', { attribution: gsiattr });
var osm = L.tileLayer('http://tile.openstreetmap.jp/{z}/{x}/{y}.png',
          { attribution: "<a href='http://osm.org/copyright' target='_blank'>OpenStreetMap</a> contributors" });
var gsiattr = "<a href='http://portal.cyberjapan.jp/help/termsofuse.html' target='_blank'>地理院タイル</a>";
// ここからlegend
var gsirelief = L.tileLayer('http://cyberjapandata.gsi.go.jp/xyz/relief/{z}/{x}/{y}.png', { opacity: 0.7, maxNativeZoom: 15, attribution: gsiattr });
var gsirehillshademap = L.tileLayer('http://cyberjapandata.gsi.go.jp/xyz/hillshademap/{z}/{x}/{y}.png', { opacity: 0.5, maxNativeZoom: 16, attribution: gsiattr });

var baseMap = {
  "地理院地図": tilelayer,
};

var overlayMaps = {
  "色別標高図": gsirelief,
  "陰影起伏図": gsirehillshademap
};
//L.control.layers(baseMap).addTo(map);

var legend = L.control({position: 'bottomright'});
legend.onAdd = function(map) {
  this._div = L.DomUtil.create('div', 'custom-panel leaflet-bar');
  var styles = {
    width :'200px',
    height: '200px',
    backgroundColor: 'black'
  }
  this._div.style.width = '100px';
  this._div.style.height = '200px';
  this._div.style.backgroundColor = 'white';
  
  this._div.innerHTML = 'aaaaaaaaaaaa';
  //this._div.style = styles
  console.log(this._div)
  return this._div;
};
legend.addTo(map);

var a = L.circle()
var overlays = {
  '<span style="color:red">aaaaaaaaaa</span>': m,

}

L.control.layers(null, overlays, { collapsed: false }).addTo(map)

var htmlLegend3 = L.control.htmllegend({
  position: 'bottomright',
  legends: [{
    name: 'Layer 1',
    layer: m,
    elements: [{
        label: 'Rectangle',
        html: '',
        style: {
            'background-color': 'red',
            'width': '10px',
            'height': '10px'
        }
    }]
}],

collapseSimple: false,
detectStretched: false,
//collapsedOnInit: false,
//defaultOpacity: 0.7,
//visibleIcon: 'icon icon-eye',
//hiddenIcon: 'icon icon-eye-slash'
})

map.addControl(htmlLegend3)


// legend#############################################


//map.addControl(timedimensioncustom);
var heat_map_6d84a20c812948f7b6b18b54cfb2fa0b = new TDHeatmap(testdata,     
    {heatmapOptions: {
            radius: 20,
            minOpacity: 0,
            maxOpacity: 1,
            scaleRadius: false,
            useLocalExtrema: false,
            defaultWeight: 1,
            latField: 'lat', //default:"lat"
            lngField: 'lng', //default:"lng"
            valueField: 'count1', //default:"value" 
            gradient: {0.4: 'blue', 0.5: 'lime', 0.6: 'yellow', 0.75: 'blue'}
        }
    })
    .addTo(map);


//ココマデ################################################################################### 

}, []);

  return <div id="map" style={{ height: "100vh" }}></div>;
}