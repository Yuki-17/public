 export default class set{

 getter() {
    return 1;
  }

}
 