import React, { Component } from 'react'
import { BrowserRouter, Route, Link } from 'react-router-dom'
import Apphaisen from './App-haisen';
import './App.css';
//import Apphatuden from './Apphatuden';
const App = () => (
  <div>
    <h2>Home</h2>
    <div> <button onclick='location.href="./plan/index"'>listへ</button> </div>
    <a href="./aaa/index">遷移</a>

  </div>
)

const Home = () => (
  <div>
    <h2>Home</h2>
    <div> <button><Link to='/plan'>listへ</Link></button> </div>

  </div>
)

const List = () => (
  <div>
    <title>sssssss</title>
    <h2>発電計画リスト</h2>
    <div className = 'list'>
    <input type="text" name="tab" value=""></input>
    
    <button><a href="http://localhost/plan">遷移</a></button>
    </div>
  </div>
)
const haisen = (aaaa) => (
  
      <div>
        <Apphaisen id = {this.props.match}/>
      </div>
)

export default List