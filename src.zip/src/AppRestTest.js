import React from 'react';
import axios from 'axios'
import 'bootstrap/dist/css/bootstrap.min.css';
import { makeStyles } from '@material-ui/core/styles';

import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import BootstrapTable from 'react-bootstrap-table-next';



export default function SimpleTable() {

  const [posts, setPosts] = useState([]);
  axios
            .get('http://http://127.0.0.1:8000/polls/')             //リクエストを飛ばすpath
            .then(response => {
                setPosts(response.data);
            })                               //成功した場合、postsを更新する（then）
            .catch(() => {
                console.log('通信に失敗しました');
            });                
  return (
    <div>
  {response}
  
    </div>
  );
}