import './App.css';
import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import HeaderTiltles from './AppheaderTitles';
import Headers from './AppHeaders';
import DataBlock from './AppDataTitles';


export default function SimpleTable() {

  return (
<div>
<title>sssssss</title>
<h2>発電計画リスト</h2>
<button><Link to='/plan/haisen'>表示</Link></button> 
</div>
  );
}