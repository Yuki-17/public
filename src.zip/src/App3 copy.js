import React from 'react';
import { render } from 'react-dom';
import { Map, MapContainer, Marker, Popup, TileLayer } from 'react-leaflet';
//import HeatmapLayer from 'react-leaflet-heatmap-layer';
import {HeatmapLayer} from '../node_modules/react-leaflet-heatmap-layer/lib/HeatmapLayer.js';
import { dataPoints, addressPoints } from './Data.js';

class App3 extends React.Component {

  render() {
    return (
      <div>
        <MapContainer center={[0,0]} zoom={13}>
        <HeatmapLayer
points={dataPoints}
longitudeExtractor={(m) => m.coordinates[0]}
latitudeExtractor={(m) => m.coordinates[1]}
intensityExtractor={(m) => 100}
/>
          <TileLayer
            url='http://{s}.tile.osm.org/{z}/{x}/{y}.png'
            attribution='&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
          />
        </MapContainer>
      </div>
    );
  }

}
export default App3